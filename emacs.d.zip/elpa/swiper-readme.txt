This package gives an overview of the current regex search
candidates.  The search regex can be split into groups with a
space.  Each group is highlighted with a different face.

It can double as a quick `regex-builder', although only single
lines will be matched.
